package mongo;

public class Employee {

	private String surname;
	private String name;
	private String company;
	private String role;
	private int age;

	public Employee(String surname, String name, String company, String role, int age) {
		this.surname = surname;
		this.name = name;
		this.company = company;
		this.role = role;
		this.age = age;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String name) {
		this.name = surname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
