package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//https://examples.javacodegeeks.com/spring-boot-mapstruct-example/#google_vignette
@SpringBootApplication
public class SpringBootMapStructApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMapStructApp.class, args);
	}
}
