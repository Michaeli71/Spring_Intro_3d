package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.demo.controller.ValidateRequestBodyController;
import com.example.demo.domain.Input;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class SpringBootValidationApp implements CommandLineRunner {

	@Autowired
	private ValidateRequestBodyController controller;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootValidationApp.class, args);

	}

	@Override
	public void run(String... args) throws Exception {

		Input validInput = new Input(1, "1.2.3.4");
		Input failureInput = new Input(1, "a.b.c.d");
		
		// ACHTUNG: nur normaler Methodenaufruf!! @Valid und @RequestBody werden nicht ausgewertet!
		ResponseEntity<String> response1 = controller.validateBody(validInput);
		System.out.println("response1: " + response1);
		
		ResponseEntity<String> response2 = controller.validateBody(failureInput);
		System.out.println("response1: " + response2);
	}	
}
