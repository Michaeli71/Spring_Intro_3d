package com.example.demo;

import org.springframework.web.client.RestTemplate;

import com.example.demo.domain.Input;

public class StandaloneApp {

	public static void main(String[] args) {
		
		Input validInput = new Input(1, "1.2.3.4");
		Input failureInput = new Input(1, "a.b.c.d");
		
		// bei Aufruf von extern werden die Daten korrekt ausgewertet
		String url = "http://localhost:8080/validateBody";
		RestTemplate restTemplate = new RestTemplate();
		String postForObject = restTemplate.postForObject(url, validInput, String.class);
		
		System.out.println("postForObject: " + postForObject);
		restTemplate.postForObject(url, failureInput, String.class);		
	}
}
