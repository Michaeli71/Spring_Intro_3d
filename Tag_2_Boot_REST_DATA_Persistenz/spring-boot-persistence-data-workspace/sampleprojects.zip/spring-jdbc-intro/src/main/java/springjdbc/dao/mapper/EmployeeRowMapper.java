package springjdbc.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import springjdbc.domain.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {
	
	@Override
	public Employee mapRow(ResultSet resultSet, int i) throws SQLException 
	{
		Employee person = new Employee();
		person.setId(resultSet.getInt(1));
		person.setName(resultSet.getString(2));
		person.setSalary(resultSet.getFloat(3));
		return person;
		
		// return new Employee(rs.getInt(1), rs.getString(2), rs.getFloat(3));
	}
}