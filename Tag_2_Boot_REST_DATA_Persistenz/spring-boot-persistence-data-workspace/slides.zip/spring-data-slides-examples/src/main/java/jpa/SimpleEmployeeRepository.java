package jpa;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface SimpleEmployeeRepository extends CrudRepository<SimpleEmployee, Long> {

  SimpleEmployee findByFirstName(String firstName);

  List<SimpleEmployee> findByLastName(String lastName);
}
