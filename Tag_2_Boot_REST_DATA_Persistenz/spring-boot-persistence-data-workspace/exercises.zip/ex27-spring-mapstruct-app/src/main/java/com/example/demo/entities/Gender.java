package com.example.demo.entities;

public enum Gender {
	MALE, FEMALE, UNSPECIFIED
}
