package com.example.demo.mapper;

public interface BikeMapper {

	// TODO
}
