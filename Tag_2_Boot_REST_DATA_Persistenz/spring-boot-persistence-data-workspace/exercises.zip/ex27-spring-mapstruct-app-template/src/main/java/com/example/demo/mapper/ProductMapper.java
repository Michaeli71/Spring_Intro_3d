package com.example.demo.mapper;

// TODO
public interface ProductMapper {
    // TODO
}
