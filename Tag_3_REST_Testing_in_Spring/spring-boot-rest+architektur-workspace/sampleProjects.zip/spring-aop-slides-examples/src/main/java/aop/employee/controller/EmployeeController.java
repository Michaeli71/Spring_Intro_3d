package aop.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import aop.employee.model.Employee;
import aop.employee.service.EmployeeService;

// http://localhost:8080/add/employee?name=Peter&empId=1234

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@RequestMapping(value = "/add/employee", method = RequestMethod.GET)
	public Employee addEmployee(@RequestParam("name") String name, @RequestParam("empId") String empId) {

		return employeeService.createEmployee(name, empId);

	}

	@RequestMapping(value = "/remove/employee", method = RequestMethod.GET)
	public String removeEmployee(@RequestParam("empId") String empId) {

		employeeService.deleteEmployee(empId);

		return "Employee removed";
	}

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public String getEmployeeById(@RequestParam("empId") String empId) {

		employeeService.getEmployeeById(empId);

		return "Employee retrieved";
	}
	
	
}
