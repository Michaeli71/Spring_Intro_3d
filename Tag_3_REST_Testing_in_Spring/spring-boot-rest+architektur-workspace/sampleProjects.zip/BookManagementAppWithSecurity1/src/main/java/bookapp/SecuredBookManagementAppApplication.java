package bookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


// Using generated security password: c3f33210-98a7-46d6-80ad-2b2743daa3c5

@SpringBootApplication
public class SecuredBookManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuredBookManagementAppApplication.class, args);
	}
}
