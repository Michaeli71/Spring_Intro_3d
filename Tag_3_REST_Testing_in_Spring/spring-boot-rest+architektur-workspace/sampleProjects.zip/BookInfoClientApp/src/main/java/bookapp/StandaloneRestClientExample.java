package bookapp;

import java.time.LocalDate;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import bookapp.entities.Book;

public class StandaloneRestClientExample {

	public static final String SERVER_URI = "http://localhost:8888/books";

	public static void main(String args[]) {

		RestTemplate restTemplate = new RestTemplate();

		getAllBooks(restTemplate);
		System.out.println("*****");
		getBook100(restTemplate);
		System.out.println("*****");
		createBook(restTemplate);
		System.out.println("*****");
		getAllBooks(restTemplate);
		System.out.println("*****");
	}

	private static void createBook(RestTemplate restTemplate) {

		// Imagionary ISBM
		//Book book = new Book("Java Profi", "Michael Inden", LocalDate.of(2011, 1, 31), "1122334");
		// ISBN10
		//Book book = new Book("Java Profi 5", "Michael Inden", LocalDate.of(2011, 11, 20), "3864907071");
		// ISBN-13
		Book book = new Book("Java Profi 5", "Michael Inden", LocalDate.of(2011, 11, 20), "978-3864907074");
		//Book book2 = new Book("Effective Java", "Joshua Bloch", LocalDate.of(2011, 11, 20), "978-3864907074");
		
		Book response = restTemplate.postForObject(SERVER_URI, book, Book.class);
		System.out.println(response);
		
		//Book response2 = restTemplate.postForObject(SERVER_URI, book2, Book.class);
	}

	public static List<Book> getAllBooks(RestTemplate restTemplate) {
		List<Book> books = (List<Book>) restTemplate.getForObject(SERVER_URI, List.class);
		System.out.println(books);

		return books;
	}

	public static Book getBook100(RestTemplate restTemplate) {
		Book book100 = restTemplate.getForObject(SERVER_URI + "/100", Book.class);
		System.out.println(book100);

		return book100;
	}
}