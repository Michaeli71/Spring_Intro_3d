package user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import user.entities.User;
import user.repositories.UserDao;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	
	public User createUser(String email, String name) {
		User user = new User(email, name);
		userDao.save(user);

		return user;
	}

	public User createUser(@Valid User user) {
		userDao.save(user);

		return user;
	}
	
	public List<User> getAll() {
		List<User> result = new ArrayList<>();
		userDao.findAll().forEach(result::add);
		return result;
	}
	
	public String getByEmail(String email) {
		Optional<User> optUser = userDao.findByEmail(email);
		if (optUser.isPresent()) {
			return String.valueOf(optUser.get().getId());
		}
		throw new UserNotFoundException("user not found for email " + email);
	}

	public String updateUser(long id, String email, String name) {
		Optional<User> optUser = userDao.findById(id);
		if (optUser.isPresent()) {
			User user = optUser.get();
			user.setEmail(email);
			user.setName(name);
			userDao.save(user);
			return "User succesfully updated!";
		}

		throw new UserNotFoundException("user not found for id " + id);
	}

	public void deleteById(long id) {
		
		// => internal server error bei falscher ID
		//userDao.deleteById(id);
		
		Optional<User> optUser = userDao.findById(id);
		if (optUser.isPresent()) {
			userDao.deleteById(id);
		}

		throw new UserNotFoundException("user not found for id " + id);
		

	}

	public User getById(long id) {
		Optional<User> optUser = userDao.findById(id);
		if (optUser.isPresent()) {
			return optUser.get();
		}

		throw new UserNotFoundException("user not found for id " + id);
	}
}
