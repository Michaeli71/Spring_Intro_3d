package productapp.errorhandling;

public class ProductNotFoundException extends RuntimeException
{

}
