package productapp.errorhandling;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ProductNotFoundAdvice {
	
	@ExceptionHandler
	void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {

		response.sendError(HttpStatus.CONFLICT.value());
	}

	@ExceptionHandler
	void handleIllegalArgumentException(ProductNotFoundException e, HttpServletResponse response) throws IOException {

		response.sendError(HttpStatus.BAD_REQUEST.value());
	}
		
	@ExceptionHandler
	void handleIllegalArgumentException(Exception e, HttpServletResponse response) throws IOException {

		response.sendError(HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
}

