package com.example.demo.services;
public interface SomeService {
    String NAME = "demo_SomeService";

    String hello(String input);
}