package bookapp.restclients;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import bookapp.entities.Book;

@Component
public class BookInfoClient {

	public static final String SERVER_URI = "http://localhost:8888/books";

	// ACHTUNG: geht nicht!!
	// @Autowired
	private RestTemplate restTemplate;

	@Autowired
	public BookInfoClient(RestTemplateBuilder builder) {
	    this.restTemplate = builder.build();
	    
	    // sauberes Fehlerhandling
	    this.restTemplate.setErrorHandler(new BookInfoErrorHandler());
	}
		
	@SuppressWarnings("unchecked")
	public List<Book> getAllBooks() {
		List<Book> books = (List<Book>) restTemplate.getForObject(SERVER_URI, List.class);
		System.out.println(books);

		return books;
	}

	public Book getBook100() {
		Book book100 = restTemplate.getForObject(SERVER_URI + "/100", Book.class);
		System.out.println(book100);

		return book100;
	}
	
	public void createBook(Book book) {
		Book response = restTemplate.postForObject(SERVER_URI, book, Book.class);
		System.out.println(response);
	}
}