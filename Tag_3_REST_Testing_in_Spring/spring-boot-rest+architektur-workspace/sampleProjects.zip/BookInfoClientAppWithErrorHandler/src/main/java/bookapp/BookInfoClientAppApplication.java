package bookapp;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import bookapp.entities.Book;
import bookapp.restclients.BookInfoClient;

@SpringBootApplication
public class BookInfoClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookInfoClientAppApplication.class, args);
	}
	
	@Component
	public class MyCommandLineRunner implements CommandLineRunner {

		@Autowired
		BookInfoClient client;
		
	    @Override
	    public void run(String... args) throws Exception {
			client.getAllBooks();
			client.getBook100();

			// Imagionary ISBM
			//Book book = new Book("Java Profi", "Michael Inden", LocalDate.of(2011, 1, 31), "1122334");
			
			// valid ISBN10
			Book book = new Book("Java Profi 5", "Michael Inden", LocalDate.of(2011, 11, 20), "3864907071");
			// valid ISBN13
			//Book book = new Book("Java Profi 5", "Michael Inden", LocalDate.of(2011, 11, 20), "978-3864907074");	
			
			client.createBook(book);
			
			client.getAllBooks();
	    }
	}
}
