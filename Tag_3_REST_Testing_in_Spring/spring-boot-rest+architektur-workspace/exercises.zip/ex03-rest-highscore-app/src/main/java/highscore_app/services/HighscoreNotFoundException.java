package highscore_app.services;

public class HighscoreNotFoundException extends IllegalArgumentException {

	public HighscoreNotFoundException() {
		super();
	}

	public HighscoreNotFoundException(String s) {
		super(s);
	}
}
