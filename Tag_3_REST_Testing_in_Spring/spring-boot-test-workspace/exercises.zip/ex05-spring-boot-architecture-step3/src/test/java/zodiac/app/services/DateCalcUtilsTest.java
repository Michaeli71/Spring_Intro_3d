package zodiac.app.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class DateCalcUtilsTest {
	// Einfach zu erweitern ...
	// Auch leicht V2 und "Nicer" zu testen
		
	@ParameterizedTest
	@CsvSource({"1979-07-14, Sheep", "2018-01-23, Dog",
		"1972-03-17, Rat", "1945-12-02, Rooster",
		"2003-08-04, Sheep"})
    void testGetBirthdayChineseSign(LocalDate birthday, String expecteZodiac) {
        String zodiac = DateCalcUtils.getChineseZodiac(birthday);
        
        assertEquals(expecteZodiac, zodiac);
    }

	@ParameterizedTest
	@CsvSource({"1979-07-14, Cancer", "2018-01-23, Aquarius",
		"1972-03-17, Pisces", "1945-12-02, Sagittarius",
		"2003-08-04, Leo"})
    void testGetBirthdayStarSign(LocalDate birthday, String expecteSign) {
        
		String startSign = DateCalcUtils.getStarSign(birthday);
        
        assertEquals(expecteSign, startSign);
    }
}
