package zodiac.app.services;

import java.time.LocalDate;
import java.time.Month;
import java.util.Map;
import java.util.function.Predicate;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@Service
public class ImprovedBirthdayService implements BirthdayService {

	@Override
	public String getBirthDOW(LocalDate birthday) {
		return birthday.getDayOfWeek().toString();
	}

	
	// Variante 1
	static Map<Integer, String> yearToZodiac = Map.ofEntries(Map.entry(0, "Monkey"), Map.entry(1, "Rooster"),
			Map.entry(2, "Dog"), Map.entry(3, "Pig"), Map.entry(4, "Rat"), Map.entry(5, "Ox"), Map.entry(6, "Tiger"),
			Map.entry(7, "Rabbit"), Map.entry(8, "Dragon"), Map.entry(9, "Snake"), Map.entry(10, "Horse"),
			Map.entry(11, "Sheep"));

	public String getChineseZodiac(LocalDate birthday) {
		System.out.println("getChineseZodiac");
		int normalizedYear = birthday.getYear() % 12;

		return yearToZodiac.getOrDefault(normalizedYear, "");
	}

	// Variante 2

	static String[] zodiacs = { "Monkey", "Rooster", "Dog", "Pig", "Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse",
			"Sheep" };

	public String getChineseZodiacV2(LocalDate birthday) {
		System.out.println("getChineseZodiacV2");
		int normalizedYear = birthday.getYear() % 12;

		return zodiacs[normalizedYear];
	}
	
	
	
	public String getStarSignNicer(LocalDate birthday) {

		if (isBetween(birthday, Month.DECEMBER, 22, Month.JANUARY, 20))
			return "Capricorn";
		if (isBetween(birthday, Month.JANUARY, 20, Month.FEBRUARY, 19))
			return "Aquarius";
		if (isBetween(birthday, 2, 19, 3, 21))
			return "Pisces";
		if (isBetween(birthday, 3, 21, 4, 20))
			return "Aries";
		if (isBetween(birthday, 4, 20, 5, 21))
			return "Taurus";
		if (isBetween(birthday, 5, 21, 6, 21))
			return "Gemini";
		if (isBetween(birthday, 6, 21, 7, 23))
			return "Cancer";
		if (isBetween(birthday, 7, 23, 8, 23))
			return "Leo";
		if (isBetween(birthday, 8, 23, 9, 23))
			return "Virgo";
		if (isBetween(birthday, 9, 23, 10, 23))
			return "Libra";
		if (isBetween(birthday, 10, 23, 11, 22))
			return "Scorpio";
		if (isBetween(birthday, 11, 22, 12, 22))
			return "Sagittarius";

		return "";
	}

	boolean isBetween(LocalDate birthday, int startmonth, int startday, int endmonth, int endday) {
		int day = birthday.getDayOfMonth();
		int month = birthday.getMonthValue();

		return month == startmonth && day >= startday || month == endmonth && day < endday;
	}
	
	boolean isBetween(LocalDate birthday, Month startmonth, int startday, Month endmonth, int endday) {
		int day = birthday.getDayOfMonth();
		int month = birthday.getMonthValue();

		return month == startmonth.getValue() && day >= startday || month == endmonth.getValue() && day < endday;
	}

	Map<Predicate<LocalDate>, String> starSignMap = Map.ofEntries(

			Map.entry(isBetweenPred(Month.DECEMBER, 22, Month.JANUARY, 20), "Capricorn"), 
			Map.entry(isBetweenPred(Month.JANUARY, 20, Month.FEBRUARY, 19), "Aquarius"),
			Map.entry(isBetweenPred(2, 19, 3, 21), "Pisces"), 
			Map.entry(isBetweenPred(3, 21, 4, 20), "Aries"),
			Map.entry(isBetweenPred(4, 20, 5, 21), "Taurus"), Map.entry(isBetweenPred(5, 21, 6, 21), "Gemini"),
			Map.entry(isBetweenPred(6, 21, 7, 23), "Cancer"), Map.entry(isBetweenPred(7, 23, 8, 23), "Leo"),
			Map.entry(isBetweenPred(8, 23, 9, 23), "Virgo"), Map.entry(isBetweenPred(9, 23, 10, 23), "Libra"),
			Map.entry(isBetweenPred(10, 23, 11, 22), "Scorpio"),
			Map.entry(isBetweenPred(11, 22, 12, 22), "Sagittarius"));

	@Override
	public String getStarSign(LocalDate birthday) {

		for (Predicate<LocalDate> pred : starSignMap.keySet()) {
			if (pred.test(birthday))
				return starSignMap.get(pred);

		}
		return "";
	}

	Predicate<LocalDate> isBetweenPred(int startmonth, int startday, int endmonth, int endday) {

		return localdate -> {
			int day = localdate.getDayOfMonth();
			int month = localdate.getMonthValue();

			return month == startmonth && day >= startday || month == endmonth && day < endday;
		};
	}
	
	Predicate<LocalDate> isBetweenPred(Month startmonth, int startday, Month endmonth, int endday) {

		return localdate -> {
			int day = localdate.getDayOfMonth();
			int month = localdate.getMonthValue();

			return month == startmonth.getValue() && day >= startday || month == endmonth.getValue() && day < endday;
		};
	}
}