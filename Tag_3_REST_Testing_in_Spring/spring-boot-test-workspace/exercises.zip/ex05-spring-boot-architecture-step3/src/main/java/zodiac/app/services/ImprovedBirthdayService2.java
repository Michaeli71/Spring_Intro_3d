package zodiac.app.services;

import java.time.LocalDate;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

//@Primary
@Service
public class ImprovedBirthdayService2 implements BirthdayService {

	@Override
	public String getBirthDOW(LocalDate birthday) {
		return birthday.getDayOfWeek().toString();
	}

	public String getChineseZodiac(LocalDate birthday) {
		boolean useMapBasedVersion = true;
		if (useMapBasedVersion)
			return DateCalcUtils.getChineseZodiac(birthday);
		
		return DateCalcUtils.getChineseZodiacV2(birthday);
	}

	@Override
	public String getStarSign(LocalDate birthday) {
		boolean useNicerVersion = true;
		if (useNicerVersion)
			return DateCalcUtils.getStarSignNicer(birthday);
		
		return DateCalcUtils.getStarSign(birthday);
	}

}