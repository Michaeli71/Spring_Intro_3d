package zodiac.appclient.services;

import org.junit.jupiter.api.Test;


public class ZodiacClientTest {
	         
	@Test
	void testZodiac()
	{
		// TODO
	}
}
