package zodiac.appclient.services;

import org.junit.jupiter.api.Test;


public class ZodiacClientMockedServerTest {
	
    @Test
    public void testServiceCall() 
    {
        // TODO
    }
}
