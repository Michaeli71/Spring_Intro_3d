package order.app.repositories;

import org.springframework.data.repository.CrudRepository;

import order.app.entities.Payment;

public interface PaymentRepository extends CrudRepository<Payment, Long>
{
}