package order.app.services;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import order.app.entities.Order;
import order.app.entities.Payment;
import order.app.repositories.OrderRepository;
import order.app.repositories.PaymentRepository;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private PaymentRepository paymentRepository;

    public Payment pay(Long orderId, String creditCardNumber) {
        System.out.println(orderRepository.getClass());
        System.out.println(paymentRepository.getClass());
    	
        Order order = orderRepository.findById(orderId).orElseThrow(EntityNotFoundException::new);

        if (order.isPaid()) {
            throw new PaymentException();
        }

        orderRepository.save(order.markAsPaid());
        
        return paymentRepository.save(new Payment(order, creditCardNumber));
    }
}
