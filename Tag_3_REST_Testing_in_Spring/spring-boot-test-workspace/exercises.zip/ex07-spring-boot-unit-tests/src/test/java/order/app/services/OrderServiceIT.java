package order.app.services;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import order.app.entities.Order;
import order.app.entities.Payment;
import order.app.repositories.OrderRepository;

@SpringBootTest
public class OrderServiceIT {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private OrderService orderService;

	@Test
	void payOrder() {
		Order order = new Order(1L, false);
		orderRepository.save(order);

		Payment payment = orderService.pay(1L, "4532756279624064");

		assertThat(payment.getOrder().isPaid()).isTrue();
		assertThat(payment.getCreditCardNumber()).isEqualTo("4532756279624064");
		
        System.out.println(orderRepository.getClass());
	}
}