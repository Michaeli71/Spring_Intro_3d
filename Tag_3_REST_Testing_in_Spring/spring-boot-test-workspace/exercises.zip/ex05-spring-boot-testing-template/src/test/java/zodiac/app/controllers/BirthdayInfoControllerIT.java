package zodiac.app.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

//TDOO
public class BirthdayInfoControllerIT {
	String bd1 = LocalDate.of(1979, 7, 14).toString();
	String bd2 = LocalDate.of(2018, 1, 23).toString();
	String bd3 = LocalDate.of(1972, 3, 17).toString();
	String bd4 = LocalDate.of(1945, 12, 2).toString();
	String bd5 = LocalDate.of(2003, 8, 4).toString();

	// TDOO

	@Test
	public void testGetBirthdayDOW() throws Exception {
		testDOW(bd1, "SATURDAY");
		testDOW(bd2, "TUESDAY");
		testDOW(bd3, "FRIDAY");
		testDOW(bd4, "SUNDAY");
		testDOW(bd5, "MONDAY");
	}

	@Test
	public void testGetBirthdayChineseSign() throws Exception {
		testZodiak(bd1, "Sheep");
		testZodiak(bd2, "Dog");
		testZodiak(bd3, "Rat");
		testZodiak(bd4, "Rooster");
		testZodiak(bd5, "Sheep");
	}

	@Test
	public void testGetBirthdayStarSign() throws Exception {
		testStarSign(bd1, "Cancer");
		testStarSign(bd2, "Aquarius");
		testStarSign(bd3, "Pisces");
		testStarSign(bd4, "Sagittarius");
		testStarSign(bd5, "Leo");
	}

	private void testDOW(String birthday, String dow) throws Exception {
		/*
		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post("/birthday/dayOfWeek").content(birthday)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn();

		String resultDOW = result.getResponse().getContentAsString();

		assertEquals(dow, resultDOW);
		*/
	}

	private void testZodiak(String birthday, String czs) throws Exception {
		// TDOO
	}

	private void testStarSign(String birthday, String ss) throws Exception {
		// TDOO
	}
}