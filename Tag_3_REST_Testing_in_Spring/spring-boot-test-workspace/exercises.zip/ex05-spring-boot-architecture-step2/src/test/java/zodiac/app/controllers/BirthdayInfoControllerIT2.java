package zodiac.app.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import zodiac.app.services.BasicBirthdayService;

@ContextConfiguration(classes = { BirthdayInfoController.class, BasicBirthdayService.class })
@WebMvcTest
class BirthdayInfoControllerIT2 {

	@Autowired
	private MockMvc mockMvc;
		    	
	@ParameterizedTest
	@CsvSource({"1979-07-14, SATURDAY", "2018-01-23, TUESDAY",
		"1972-03-17, FRIDAY", "1945-12-02, SUNDAY",
		"2003-08-04, MONDAY"})
	public void testGetBirthdayDOW(String birthday, String expectedWeekDay) throws Exception {
		String resultDOW = performCall(birthday, "/birthday/dayOfWeek").getResponse().getContentAsString();
		
		assertEquals(expectedWeekDay, resultDOW);
	}
	
	@ParameterizedTest
	@CsvSource({"1979-07-14, Sheep", "2018-01-23, Dog",
		"1972-03-17, Rat", "1945-12-02, Rooster",
		"2003-08-04, Sheep"})
	public void testGetBirthdayChineseSign(String birthday, String expectedZodiac) throws Exception {
		String resultCZ = performCall(birthday, "/birthday/chineseZodiac").getResponse().getContentAsString();
		
		assertEquals(expectedZodiac, resultCZ);
	}
	
	@ParameterizedTest
	@CsvSource({"1979-07-14, Cancer", "2018-01-23, Aquarius",
		"1972-03-17, Pisces", "1945-12-02, Sagittarius",
		"2003-08-04, Leo"})
	public void testGetBirthdaytestStarSign(String birthday, String expecteSign) throws Exception {
		String resultSS = performCall(birthday, "/birthday/starSign").getResponse().getContentAsString();
		
		assertEquals(expecteSign, resultSS);
	}
	
	private MvcResult performCall(String birthday, String path) throws Exception {
		return mockMvc
				.perform(MockMvcRequestBuilders.post(path).content(birthday)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn();
	}
}