package zodiac.app.services;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class BasicBirthdayServiceTest {
    BirthdayService birthdayService = new BasicBirthdayService();
    
	@ParameterizedTest
	@CsvSource({"1979-07-14, SATURDAY", "2018-01-23, TUESDAY",
		"1972-03-17, FRIDAY", "1945-12-02, SUNDAY",
		"2003-08-04, MONDAY"})
    void testGetBirthdayDOW(LocalDate birthday, String expecteDOW) {
        String dow = birthdayService.getBirthDOW(birthday);
        
        assertEquals(expecteDOW, dow);
    }

	@ParameterizedTest
	@CsvSource({"1979-07-14, Sheep", "2018-01-23, Dog",
		"1972-03-17, Rat", "1945-12-02, Rooster",
		"2003-08-04, Sheep"})
    void testGetBirthdayChineseSign(LocalDate birthday, String expecteZodiac) {
        String zodiac = birthdayService.getChineseZodiac(birthday);
        
        assertEquals(expecteZodiac, zodiac);
    }

	@ParameterizedTest
	@CsvSource({"1979-07-14, Cancer", "2018-01-23, Aquarius",
		"1972-03-17, Pisces", "1945-12-02, Sagittarius",
		"2003-08-04, Leo"})
    void testGetBirthdayStarSign(LocalDate birthday, String expecteSign) {
        
		String startSign = birthdayService.getStarSign(birthday);
        
        assertEquals(expecteSign, startSign);
    }
}
