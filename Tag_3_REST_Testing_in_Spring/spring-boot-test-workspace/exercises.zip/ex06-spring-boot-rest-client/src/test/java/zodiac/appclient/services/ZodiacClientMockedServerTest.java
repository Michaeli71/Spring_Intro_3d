package zodiac.appclient.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;


@RestClientTest({ZodiacClient.class })
public class ZodiacClientMockedServerTest {
	
	@Autowired
    private MockRestServiceServer mockServer;
 
    @Autowired
    private ZodiacClient client;

    @Test
    public void testServiceCall() 
    {
        mockServer.expect(requestTo("http://localhost:8080/birthday/chineseZodiac?birthdayString=1971-02-07"))
                    .andRespond(withSuccess("TIGER", MediaType.TEXT_PLAIN));
                
        String userServiceResponse = client.getZodiac(LocalDate.of(1971, 2, 7));
         
        assertThat(userServiceResponse).isEqualTo("TIGER");
    }
}
