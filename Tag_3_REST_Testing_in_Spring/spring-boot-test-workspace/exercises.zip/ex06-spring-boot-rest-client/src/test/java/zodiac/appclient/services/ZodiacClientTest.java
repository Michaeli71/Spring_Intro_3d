package zodiac.appclient.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class ZodiacClientTest {
	 
    @Autowired
    private ZodiacClient client;
        
	@Test
	void testZodiac()
	{
		// => http://localhost:8080/birthday/chineseZodiac?birthdayString=1971-02-07
		// => anderer Server muss laufen!
		/*
		String result = client.getZodiac(LocalDate.of(1971, 2, 7));
		
		assertEquals("Pig", result);
		 */
	}
}
