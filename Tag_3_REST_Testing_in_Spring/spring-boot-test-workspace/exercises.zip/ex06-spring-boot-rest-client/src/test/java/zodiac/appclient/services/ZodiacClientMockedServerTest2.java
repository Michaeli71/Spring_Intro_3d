package zodiac.appclient.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.time.LocalDate;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;


@RestClientTest({ZodiacClient.class })
public class ZodiacClientMockedServerTest2 {
	
	@Autowired
    private MockRestServiceServer mockServer;
 
    @Autowired
    private ZodiacClient client;

    @Test
    public void testServiceCall() 
    {
        mockServer.expect(requestTo(Matchers.matchesPattern(".*/birthday/chineseZodiac.*")))
        .andRespond(withSuccess("TIGER", MediaType.TEXT_PLAIN));
        
        mockServer.expect(requestTo(Matchers.matchesPattern(".*/birthday/starSign.*")))
        .andRespond(withSuccess("DRAGON", MediaType.TEXT_PLAIN));
        
        String userServiceResponse1 = client.getZodiac(LocalDate.of(1971, 2, 7));
        String userServiceResponse2 = client.getStarSign(LocalDate.of(1971, 2, 7));
         
        assertThat(userServiceResponse1).isEqualTo("TIGER");
        assertThat(userServiceResponse2).isEqualTo("DRAGON");
    }
}
