package zodiac.appclient.services;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ZodiacClient {

	private final RestTemplate restTemplate;

	@Autowired
	public ZodiacClient(RestTemplateBuilder restTemplateBuilder) {
		restTemplate = restTemplateBuilder.build();
	}

	public String getZodiac(LocalDate localdate) {
		return restTemplate.getForObject("http://localhost:8080/birthday/chineseZodiac?birthdayString=" + localdate,
				String.class);
	}

	public String getStarSign(LocalDate localdate) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_PLAIN);

		HttpEntity<String> request = new HttpEntity<String>(localdate.toString(), headers);

		return restTemplate.postForObject("http://localhost:8080/birthday/starSign", request, String.class);
	}
}