package order.app.repositories;

import org.springframework.data.repository.CrudRepository;

import order.app.entities.Order;

public interface OrderRepository extends CrudRepository<Order, Long>
{
}
