package order.app.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

// ACHTUNG ... mit Klassennamen und SQL-Befehlen !!!
@Entity(name = "ORDERS")
public class Order {

	@Id
	private long orderId;
	
	private boolean isPaid;
	
	public Order()
	{}
	
	public Order(long orderId, boolean isPaid) {
		this.orderId = orderId;
		this.isPaid = isPaid;
	}

	public boolean isPaid() {
		return isPaid;
	}

	public Order markAsPaid() {
		this.isPaid = true;
		return this;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public void setPaid(boolean isPaid) {
		this.isPaid = isPaid;
	}
}
