package order.app.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Payment {

	@Id
	@GeneratedValue
	private long paymentId;
	
	@OneToOne
	private Order order;
	private String creditCardNumber;
	
	public Payment()
	{}
	
	public Payment(Order order, String creditCardNumber) {
		this.order = order;
		this.creditCardNumber = creditCardNumber;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
}
