package order.app.services;

public class PaymentException extends RuntimeException {

}
