package testing.app;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import testing.app.entities.City;
import testing.app.repositories.CityRepository;

@Component
public class MyRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(MyRunner.class);

    @Autowired
    private CityRepository cityRepository;

    @Override
    public void run(String... args) throws Exception {

        List<City> cities = cityRepository.findByNameEndingWithAndPopulationLessThan("est", 1800000);
        cities.forEach(city -> logger.info("{}", city));
    }
}