package order.app.services;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;

import order.app.entities.Order;
import order.app.entities.Payment;
import order.app.repositories.OrderRepository;
import order.app.repositories.PaymentRepository;

@Service
public class OrderServiceImproved {

	private final OrderRepository orderRepository;
	private final PaymentRepository paymentRepository;

	// @Autowired // nicht benötigt, macht Spring bei nur 1 Ctor automatisch
	public OrderServiceImproved(OrderRepository orderRepository, PaymentRepository paymentRepository) {
        this.orderRepository = orderRepository;
        this.paymentRepository = paymentRepository;
    }

	public Payment pay(Long orderId, String creditCardNumber) {
        System.out.println(orderRepository.getClass());
        System.out.println(paymentRepository.getClass());
        
		Order order = orderRepository.findById(orderId).orElseThrow(EntityNotFoundException::new);

		if (order.isPaid()) {
			throw new PaymentException();
		}

		orderRepository.save(order.markAsPaid());

		return paymentRepository.save(new Payment(order, creditCardNumber));
	}
}
