package productclientapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import productclientapp.entities.Product;
import productclientapp.restclients.ProductInfoClient;

@SpringBootApplication
public class ProductInfoClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductInfoClientAppApplication.class, args);
	}
	
	@Component
	public class MyCommandLineRunner implements CommandLineRunner {

		@Autowired
		ProductInfoClient client;
		
	    @Override
	    public void run(String... args) throws Exception {
			client.getAllProducts();
			client.getProduct100();

			Product product = new Product(4711, "IPAD", "PRO", 10101, 12345);
			client.createProduct(product);
			
			client.getAllProducts();
	    }
	}
}
