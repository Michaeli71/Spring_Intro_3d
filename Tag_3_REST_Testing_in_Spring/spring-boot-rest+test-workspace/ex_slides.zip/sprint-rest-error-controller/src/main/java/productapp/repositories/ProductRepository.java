package productapp.repositories;

// TODO
public class ProductRepository {

}

// in Spring
// extends CrudRepository