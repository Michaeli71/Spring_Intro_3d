package bookapp.entities;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

class Customer {

  @Email
  private String email;

  @NotBlank
  private String name;
  
  // ...
}
