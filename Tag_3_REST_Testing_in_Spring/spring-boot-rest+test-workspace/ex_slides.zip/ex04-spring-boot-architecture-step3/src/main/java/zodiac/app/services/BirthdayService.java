package zodiac.app.services;

import java.time.LocalDate;

public interface BirthdayService {
	String getBirthDOW(LocalDate birthday);

	String getChineseZodiac(LocalDate birthday);

	String getStarSign(LocalDate birthday);
}