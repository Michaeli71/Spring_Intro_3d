package ch.asmiq.config;

import org.springframework.context.annotation.Configuration;

// Variante 1: Configuration mit @Primary @Bean
@Configuration
public class AsmiqAcademyAppConfig {
		
	/*
	@Primary
	@Bean
	public NotificationService smsService() {
		return new SmsService();
	}
	
	@Primary
	@Bean
	public CourseService courseService() {
		return new LiveCourseService();
	}
	*/
}



