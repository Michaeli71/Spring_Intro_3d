package ch.javaprofi;

public class GreetingApp {

	public static void main(String[] args) {

		GreetingService greetingService = new GreetingService();
		greetingService.sayHello();
	}
}
