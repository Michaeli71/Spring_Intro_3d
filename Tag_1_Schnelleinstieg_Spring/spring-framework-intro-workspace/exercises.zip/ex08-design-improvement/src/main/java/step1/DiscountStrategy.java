package step1;

import exercise.Pizza;

public interface DiscountStrategy {
	double apply(final Pizza pizza);
}
