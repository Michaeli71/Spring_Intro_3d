package step1;

import exercise.Pizza;

public class XL_HalfPrice_Discount implements DiscountStrategy 
{
	@Override
	public double apply(Pizza pizza) {
		// TODO Auto-generated method stub
		return 0;
	}

	// ...
}