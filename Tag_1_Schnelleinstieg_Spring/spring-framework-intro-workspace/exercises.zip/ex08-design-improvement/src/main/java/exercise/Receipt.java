package exercise;

public class Receipt {

	public Receipt(Customer customer) {

	}

	public void addEntry(Pizza pizza, double price) {
		
	}

}
