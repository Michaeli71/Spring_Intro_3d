package exercise;

public class Customer {

}
