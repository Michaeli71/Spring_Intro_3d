package ch.asmiq.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ch.asmiq.model.Course;
import ch.asmiq.model.Order;

@Component // @Service
public class AsmiqAcademyService {

	private CourseService courseService;
	private SmsService smsService;

//	public AsmiqAcademyService() {	
//	}
	
	// HINWEIS: Autowired by default, wenn nur ein CTOR
	@Autowired
	public AsmiqAcademyService(CourseService courseService, SmsService smsService) {
		this.courseService = courseService;
		this.smsService = smsService;
	}

	public List<Course> getCourses() {
		return courseService.getCourses();
	}
	
	public void placeOrder(Order order){
		smsService.sendNotification(order);
	}

}
