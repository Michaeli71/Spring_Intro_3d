package ch.javaprofi_academy;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@ComponentScan("ch.javaprofi_academy")
public class BeanQuaifierApp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean-def.xml");

		var someService = context.getBean(InitSequenceBean.class);

		context.close();
	}
}