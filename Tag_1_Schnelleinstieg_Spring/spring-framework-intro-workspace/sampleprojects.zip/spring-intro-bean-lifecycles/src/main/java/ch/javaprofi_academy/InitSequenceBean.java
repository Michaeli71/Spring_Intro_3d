package ch.javaprofi_academy;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;

//@Component
public class InitSequenceBean implements InitializingBean {  

    public InitSequenceBean() {  
       System.out.println("InitSequenceBean: constructor");  
    }  

    @PostConstruct  
    public void postConstruct() {  
       System.out.println("InitSequenceBean: postConstruct");  
    }  

    // <bean class="InitSequenceBean" init-method="initMethod"></bean>
    public void initMethod() {  
       System.out.println("InitSequenceBean: init-method");  
    }  

    @Override  
    public void afterPropertiesSet() throws Exception {  
       System.out.println("InitSequenceBean: afterPropertiesSet");  
    }  
}  