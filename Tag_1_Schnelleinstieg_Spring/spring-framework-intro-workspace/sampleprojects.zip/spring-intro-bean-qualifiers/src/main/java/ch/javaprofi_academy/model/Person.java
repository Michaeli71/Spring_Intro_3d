package ch.javaprofi_academy.model;

public interface Person {

	String getDescription();
}