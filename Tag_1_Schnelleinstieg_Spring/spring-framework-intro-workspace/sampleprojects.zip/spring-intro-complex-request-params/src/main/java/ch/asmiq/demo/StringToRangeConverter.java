package ch.asmiq.demo;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class StringToRangeConverter implements Converter<String, Range> {

	@Override
	public Range convert(String source) {
		
		System.out.println("Range input: " + source);
		
		String[] values = source.split(",");
		return new Range(Integer.parseInt(values[0]), Integer.parseInt(values[1]));
	}
}