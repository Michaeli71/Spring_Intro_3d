package ch.asmiq.demo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Range {
	int lower;
	int upper;

	public Range() {
	}

	public Range(int lower, int upper) {
		this.lower = lower;
		this.upper = upper;
	}

	
	public int getLower() {
		return lower;
	}

	public void setLower(int lower) {
		this.lower = lower;
	}

	public int getUpper() {
		return upper;
	}

	public void setUpper(int upper) {
		this.upper = upper;
	}

	@Override
	public String toString() {
		return "Range [lower=" + lower + ", upper=" + upper + "]";
	}
}
