package ch.asmiq.demo;

import java.util.Arrays;

public class SearchDTO {
    private Long[] ids;

    public Long[] getIds() {
        return ids;
    }

    public void setIds(Long[] ids) {
        this.ids = ids;
    }
    // reflection toString from apache commons
    @Override
    public String toString() {
        return "SearchDTO: " + Arrays.toString(ids);
    }
}