package ch.asmiq.demo;

import java.io.IOException;
import java.time.LocalDate;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class ComplexRequestParamsController {

	@GetMapping("/home")
	public String index(Model model) {
		model.addAttribute("msg", "Greetings from Spring Boot to thymeleaf!");

		return "index";
	}

	// http://localhost:8080/handle?since=1971-02-07
	@GetMapping("/since")
	public String getSince(@RequestParam LocalDate since) {

		System.out.println("since: " + since);

		return since.toString();
	}

	// http://localhost:8080/handle?range=1,7
	@GetMapping(value = "/range", produces = "application/xml")
	public Range getComplexRange(@RequestParam Range range) {

		System.out.println("range: " + range);

		// return range.toString();
		return range;
	}

	// http://localhost:8080/handle?ids=353,234
	@RequestMapping(value = "/handle", method = RequestMethod.GET)
	public String handleRequest(SearchDTO search) {
		System.out.println("criteria: " + search);
		return "OK";
	}

	@GetMapping(value = "/productCriteria")
	public ProductCriteria getComplexRange(@RequestParam ProductCriteria productCriteria) {

		System.out.println("productCriteria: " + productCriteria);
		return productCriteria;
	}

	@RequestMapping(value = "/updatePreferences")
//	public String updatePreferences(@RequestParam UserPreferences userPreferencesIn) {
	public String updatePreferences() {

		String preferencesJSon = """
				{
   "userId":"1005012365",
   "audioLevel":100,
   "tooltip":true,
   "language":"en"
}""";
		
		System.out.println("preferencesJSon: " + preferencesJSon);
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			UserPreferences userPreferences = mapper.readValue(preferencesJSon, UserPreferences.class);
			System.out.println(userPreferences);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return UriUtils.encodeQueryParam(preferencesJSon, "UTF-8");
	}
	
	//
	//%09%09%09%09%7B%0A%20%20%20%22userId%22:%221005012365%22,%0A%20%20%20%22audioLevel%22:100,%0A%20%20%20%22tooltip%22:true,%0A%20%20%20%22language%22:%22en%22%0A%7D
	//%09%09%09%09%7B%0A%20%20%20%22userId%22:%221234567%22,%0A%20%20%20%22audioLevel%22:111,%0A%20%20%20%22tooltip%22:false,%0A%20%20%20%22language%22:%22de%22%0A%7D

	@RequestMapping(value = "/updatePreferences2")
	public String updatePreferences(@RequestParam String userPreferencesIn) {
		
		System.out.println("userPreferencesIn: " + userPreferencesIn);
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			UserPreferences userPreferences = mapper.readValue(userPreferencesIn, UserPreferences.class);
			System.out.println(userPreferences);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "OK";
	}
}
