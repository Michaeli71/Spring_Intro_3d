package ch.asmiq;

public class AcademyService {

	private EMailService emailService;
	private SmsService smsService;

	public AcademyService(EMailService emailService, SmsService smsService) {
		this.emailService = emailService;
		this.smsService = smsService;
	}

	@Override
	public String toString() {
		return "AcademyService [emailService=" + emailService + ", smsService=" + smsService + "]";
	}
}
