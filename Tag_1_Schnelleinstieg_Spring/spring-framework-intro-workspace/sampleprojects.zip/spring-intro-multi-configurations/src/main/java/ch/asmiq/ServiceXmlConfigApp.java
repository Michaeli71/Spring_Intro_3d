package ch.asmiq;

import org.springframework.context.support.GenericXmlApplicationContext;

public class ServiceXmlConfigApp 
{
	public static void main(String[] args) 
	{
		var ctx = new GenericXmlApplicationContext("bean-def.xml");

		var academyService = ctx.getBean("academyService");

		System.out.println(academyService);

		ctx.close();

	}
}