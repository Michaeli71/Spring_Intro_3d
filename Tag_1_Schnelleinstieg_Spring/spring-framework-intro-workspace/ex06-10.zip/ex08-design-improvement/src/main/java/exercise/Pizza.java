package exercise;

public class Pizza {

}
