package step1;

import exercise.Customer;

public class CustomerDAO implements CustomerRepository {

	@Override
	public Customer findById(long customerId) {
		return null;
	}
}
