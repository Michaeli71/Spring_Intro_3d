package step1;

import exercise.Customer;

public interface CustomerRepository {
	Customer findById(final long customerId);
}
