package step2;

import exercise.Customer;

public interface CustomerRepository {
	Customer findById(final long customerId);
}
